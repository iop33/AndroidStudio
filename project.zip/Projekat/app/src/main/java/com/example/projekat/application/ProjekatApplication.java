package com.example.projekat.application;

import android.app.Application;

import timber.log.Timber;

public class ProjekatApplication extends Application {
    @Override
    public void onCreate() {
        super.onCreate();
        Timber.plant(new Timber.DebugTree());
    }
}
