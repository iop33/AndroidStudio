package com.example.projekat.view.fragments;

import android.content.Context;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentTransaction;

import com.example.projekat.R;
import com.example.projekat.database.DBHelper;

public class FragmentLog extends Fragment {

    public static final String PREF_MESSAGE_KEY = "prefMessageKey";
    public FragmentLog() {
        super(R.layout.fragment_log);
    }
    @Override
    public void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        //Toast toast = Toast.makeText(getActivity().getApplicationContext(),"PASSWORD MUST CONTAIN AT LEAST ONE NUMBER",Toast.LENGTH_SHORT);
        //toast.show();
        view.findViewById(R.id.button).setOnClickListener(v-> {
            String lozinka=((EditText)view.findViewById(R.id.password)).getText().toString();
            if(lozinka.contains("~") || lozinka.contains("#")|| lozinka.contains("^") || lozinka.contains("$")
                    || lozinka.contains("%")|| lozinka.contains("&")||lozinka.contains("*")||lozinka.contains("!")){
                Toast toast = Toast.makeText(getActivity().getApplicationContext(),"PASSWORD HAS FORBIDDEN CHARACTER",Toast.LENGTH_SHORT);
                toast.show();
            }
           else if(lozinka.length()<5){
                Toast toast = Toast.makeText(getActivity().getApplicationContext(),"PASSWORD MUST CONTAIN AT LEAST FIVE CHARACTERS",Toast.LENGTH_SHORT);
                toast.show();
            }
            else{
                DBHelper dbHelper=new DBHelper(getActivity());
                String loz=((EditText)view.findViewById(R.id.password)).getText().toString();
                String ime=((EditText)view.findViewById(R.id.email)).getText().toString();
                String pravoIme=((EditText)view.findViewById(R.id.username)).getText().toString();
                if(dbHelper.checkUsernamePassword(pravoIme,loz,ime)){
                    SharedPreferences sharedPreferences = getActivity().getSharedPreferences(getActivity().getPackageName(), Context.MODE_PRIVATE);
                    sharedPreferences
                            .edit()
                            .putString(PREF_MESSAGE_KEY, ime+":"+loz+":"+pravoIme)
                            .apply();
                    FragmentTransaction transaction = this.getActivity().getSupportFragmentManager().beginTransaction();
                    transaction.replace(R.id.addFragmentFcv, new FragmentMain());
                    transaction.commit();
                }
                else{
                    Toast toast = Toast.makeText(getActivity().getApplicationContext(),"YOU ARE NOT LOGGED IN!",Toast.LENGTH_SHORT);
                    toast.show();
                }

            }

        });

    }

}
