package com.example.projekat.view.activities;

import android.content.Context;
import android.content.SharedPreferences;
import android.os.Bundle;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.splashscreen.SplashScreen;
import androidx.fragment.app.FragmentTransaction;

import com.example.projekat.R;
import com.example.projekat.database.DBHelper;
import com.example.projekat.view.fragments.FragmentLog;
import com.example.projekat.view.fragments.FragmentMain;

public class MainActivity extends AppCompatActivity {

    DBHelper dbHelper;
    public static final String PREF_MESSAGE_KEY = "prefMessageKey";
    @Override
    protected void onCreate(Bundle savedInstanceState) {

        super.onCreate(savedInstanceState);
        SplashScreen splashScreen = SplashScreen.installSplashScreen(this);
        splashScreen.setKeepOnScreenCondition(() -> {
            try {
                Thread.sleep(2000);
            } catch (InterruptedException e) {
                throw new RuntimeException(e);
            }
            return false;
        });
        this.dbHelper=new DBHelper(this);
        if(!dbHelper.checkUsername("mateja")) {
            dbHelper.insertData("mateja", "password", "email");
        }
        setContentView(R.layout.activity_main);
        init();
    }

    public void init(){
        initFragments();
    }

    public void initFragments(){
        SharedPreferences sharedPreferences = getSharedPreferences(getPackageName(), Context.MODE_PRIVATE);
        String message = sharedPreferences.getString(PREF_MESSAGE_KEY, null);
        if(message==null){
            FragmentTransaction transaction = getSupportFragmentManager().beginTransaction();
            transaction.replace(R.id.addFragmentFcv, new FragmentLog());
            transaction.commit();
        }
        else{
            FragmentTransaction transaction = getSupportFragmentManager().beginTransaction();
            transaction.replace(R.id.addFragmentFcv, new FragmentMain());
            transaction.commit();
        }

    }

    @Override
    public void onBackPressed() {
        super.onBackPressed();
        this.getSupportFragmentManager().popBackStackImmediate();
    }
}
