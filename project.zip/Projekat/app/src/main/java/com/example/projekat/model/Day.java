package com.example.projekat.model;

import java.time.LocalDate;
import java.util.List;

public class Day {
    private Priority priority;
    private LocalDate dan;
    private List<DayEvent> obaveze;

    public Priority getPriority() {
        return priority;
    }

    public void setPriority(Priority priority) {
        this.priority = priority;
    }

    public LocalDate getDan() {
        return dan;
    }

    public void setDan(LocalDate dan) {
        this.dan = dan;
    }

    public List<DayEvent> getObaveze() {
        return obaveze;
    }

    public void setObaveze(List<DayEvent> obaveze) {
        this.obaveze = obaveze;
    }

    public Day(Priority priority, LocalDate dan, List<DayEvent> obaveze) {
        this.priority = priority;
        this.dan = dan;
        this.obaveze = obaveze;
    }
}
