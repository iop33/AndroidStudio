package com.example.projekat.view.recycler.differ;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.DiffUtil;

import com.example.projekat.model.Day;

public class DayDifferItemCallback extends DiffUtil.ItemCallback<Day> {
    @Override
    public boolean areItemsTheSame(@NonNull Day oldItem, @NonNull Day newItem) {
        return oldItem.getDan().compareTo(newItem.getDan()) == 0;
    }

    @Override
    public boolean areContentsTheSame(@NonNull Day oldItem, @NonNull Day newItem) {
        return oldItem.getObaveze().equals(newItem.getObaveze())
                && oldItem.getPriority().equals(newItem.getPriority());
    }
}
