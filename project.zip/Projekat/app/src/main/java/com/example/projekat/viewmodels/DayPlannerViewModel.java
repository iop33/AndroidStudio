package com.example.projekat.viewmodels;

import androidx.lifecycle.LiveData;
import androidx.lifecycle.MutableLiveData;
import androidx.lifecycle.ViewModel;

import com.example.projekat.model.Day;
import com.example.projekat.model.DayEvent;

import java.util.List;

public class DayPlannerViewModel extends ViewModel {
    private final MutableLiveData<Day> planer_dan = new MutableLiveData<>();

    public LiveData<Day> getPlaner_dan() {
        return planer_dan;
    }

    public void setPlaner_dan(Day dayEventList) {
        this.planer_dan.setValue(dayEventList);
    }
}
