package com.example.projekat.viewmodels;

import androidx.lifecycle.LiveData;
import androidx.lifecycle.MutableLiveData;
import androidx.lifecycle.ViewModel;

import com.example.projekat.model.Day;
import com.example.projekat.model.DayEvent;
import com.example.projekat.model.Priority;

import java.time.LocalDate;
import java.time.LocalTime;
import java.util.ArrayList;
import java.util.List;

public class CalendarViewModel extends ViewModel {
    public final MutableLiveData<List<Day>> dani = new MutableLiveData<>();
    private ArrayList<Day> daniList = new ArrayList<>();

    public CalendarViewModel() {
        LocalDate localDate = LocalDate.of(2022,8, 1);
        for(int i = 0; i < 10000; i++) {
            List<DayEvent> events = new ArrayList<>();
            events.add(new DayEvent("Obaveza", "Opis", LocalTime.of(11,45), LocalTime.of(12,00), Priority.LOW));
            Day day = new Day(Priority.HIGH, localDate.plusDays(i), events);
            day.setObaveze(events);
            daniList.add(day);
        }
        ArrayList<Day> listToSubmit = new ArrayList<>(daniList);
        dani.setValue(listToSubmit);
    }

    public LiveData<List<Day>> getDani() {
        return dani;
    }
}
