package com.example.projekat.model;

public enum Priority {
    LOW,MID,HIGH
}
