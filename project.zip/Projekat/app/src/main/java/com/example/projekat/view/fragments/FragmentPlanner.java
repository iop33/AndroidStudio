package com.example.projekat.view.fragments;

import android.os.Bundle;
import android.view.View;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentTransaction;
import androidx.lifecycle.ViewModelProvider;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.example.projekat.R;
import com.example.projekat.view.recycler.adapter.PlannerAdapter;
import com.example.projekat.view.recycler.differ.DayEventDifferItemCallback;
import com.example.projekat.viewmodels.CalendarViewModel;
import com.example.projekat.viewmodels.DayPlannerViewModel;
import com.example.projekat.viewmodels.PlannerViewModel;

public class FragmentPlanner extends Fragment {

    private RecyclerView recyclerView;
    private PlannerAdapter plannerAdapter;
    private PlannerViewModel plannerViewModel;
    private DayPlannerViewModel dayPlannerViewModel;
    private CalendarViewModel calendarViewModel;
    private TextView textView;
    public FragmentPlanner() {
        super(R.layout.fragment_planner);
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        recyclerView = view.findViewById(R.id.recycler_planner);
        textView=view.findViewById(R.id.danplaner);
        plannerViewModel = new ViewModelProvider(requireActivity()).get(PlannerViewModel.class);
        calendarViewModel = new ViewModelProvider(requireActivity()).get(CalendarViewModel.class);
        init();
        initRecycler();
        initObservers();
    }

    private void init() {
        dayPlannerViewModel= new ViewModelProvider(requireActivity()).get(DayPlannerViewModel.class);
        textView.setText(dayPlannerViewModel.getPlaner_dan().getValue().getDan().toString());
    }

    private void initObservers() {
        plannerViewModel.getEvents().observe(this, events -> {
            plannerAdapter.submitList(events);
        });
    }

    private void initRecycler() {
        plannerAdapter = new PlannerAdapter(new DayEventDifferItemCallback(), dayEvent -> {
            FragmentTransaction transaction = getActivity().getSupportFragmentManager().beginTransaction();
            transaction.replace(R.id.fragmentContainerView, new FragmentProfile());
            transaction.commit();
        });
        recyclerView.setLayoutManager(new LinearLayoutManager(this.getActivity()));
        recyclerView.setAdapter(plannerAdapter);
    }
}
