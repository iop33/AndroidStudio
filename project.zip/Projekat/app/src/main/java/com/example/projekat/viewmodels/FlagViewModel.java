package com.example.projekat.viewmodels;

import androidx.lifecycle.MutableLiveData;
import androidx.lifecycle.ViewModel;

public class FlagViewModel extends ViewModel {
    private final MutableLiveData<Boolean> flag = new MutableLiveData<>();

    public FlagViewModel() {
        flag.setValue(false);
    }

    public MutableLiveData<Boolean> getFlag() {
        return flag;
    }

    public void setFlag() {
        flag.setValue(true);
    }
}
