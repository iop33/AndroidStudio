package com.example.projekat.view.recycler.adapter;

import android.content.Context;
import android.graphics.drawable.Drawable;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.constraintlayout.widget.ConstraintLayout;
import androidx.recyclerview.widget.DiffUtil;
import androidx.recyclerview.widget.ListAdapter;
import androidx.recyclerview.widget.RecyclerView;

import com.example.projekat.R;
import com.example.projekat.model.DayEvent;
import com.example.projekat.model.Priority;

import java.time.LocalTime;
import java.util.function.Consumer;

public class PlannerAdapter extends ListAdapter<DayEvent, PlannerAdapter.ViewHolder> {

    private final Consumer<DayEvent> onDayEventClicked;


    public PlannerAdapter(@NonNull DiffUtil.ItemCallback<DayEvent> diffCallback, Consumer<DayEvent> onDayEventClicked) {
        super(diffCallback);
        this.onDayEventClicked = onDayEventClicked;
    }

    @NonNull
    @Override
    public PlannerAdapter.ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View itemView = LayoutInflater.from(parent.getContext()).inflate(R.layout.day_item, parent, false);
        return new ViewHolder(itemView, parent.getContext(), position -> {
            DayEvent dayEvent = getItem(position);
            onDayEventClicked.accept(dayEvent);
        });
    }

    @Override
    public void onBindViewHolder(@NonNull PlannerAdapter.ViewHolder holder, int position) {
        if(position >= 0 && position < getItemCount()) {
            DayEvent dayEvent = getItem(position);
            holder.bind(dayEvent);
        }
    }

    public static class ViewHolder extends RecyclerView.ViewHolder {

        private final Context context;

        public ViewHolder(@NonNull View itemView, Context context, Consumer<Integer> onItemClicked) {
            super(itemView);
            this.context = context;
            itemView.setOnClickListener(v -> {
                if (getBindingAdapterPosition() != RecyclerView.NO_POSITION) {
                    onItemClicked.accept(getBindingAdapterPosition());
                }
            });
        }

        public void bind(DayEvent dayEvent) {
            // TODO: Spojiti stvari iz layout-a
            ImageView imageView = itemView.findViewById(R.id.dayEventPicture);
            TextView title = itemView.findViewById(R.id.eventNameTV);
            TextView time = itemView.findViewById(R.id.eventTimeTV);
            ImageButton edit = itemView.findViewById(R.id.editImageButton);
            ImageButton delete = itemView.findViewById(R.id.deleteImageButton);
            ConstraintLayout constraintLayout = itemView.findViewById(R.id.day_single_event_item);
            title.setText(dayEvent.getIme());
            time.setText(dayEvent.getStart().toString() + "-" + dayEvent.getEnd().toString());
            if(LocalTime.now().compareTo(dayEvent.getEnd()) < 0) {
//                constraintLayout.setBackground(context.getDrawable(R.drawable.day_event_present));
//                edit.setBackgroundColor(context.getColor(R.color.backgroud_light_blue));
//                delete.setBackgroundColor(context.getColor(R.color.backgroud_light_blue));
            } else {
//                constraintLayout.setBackground(context.getDrawable(R.drawable.day_event_past));
//                edit.setBackgroundColor(context.getColor(R.color.day_event_past));
//                delete.setBackgroundColor(context.getColor(R.color.day_event_past));
            }
            Priority priority = dayEvent.getEventPriority();
            Drawable drawable = null;
            switch (priority) {
                case LOW:
                    drawable = context.getDrawable(R.drawable.low_day_box_plain);
                    break;
                case MID:
                    drawable = context.getDrawable(R.drawable.medium_day_box_plain);
                    break;
                case HIGH:
                    drawable = context.getDrawable(R.drawable.high_day_box_plain);
                    break;
                default:
                    drawable = context.getDrawable(R.drawable.day_box_plain);
                    break;
            }
            imageView.setBackground(drawable);
        }
    }
}
