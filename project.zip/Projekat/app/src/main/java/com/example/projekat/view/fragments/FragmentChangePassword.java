package com.example.projekat.view.fragments;

import android.content.Context;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentTransaction;

import com.example.projekat.R;
import com.example.projekat.database.DBHelper;

public class FragmentChangePassword extends Fragment {

    public static final String PREF_MESSAGE_KEY = "prefMessageKey";

    public FragmentChangePassword() {super(R.layout.fragment_password_change);}

    @Override
    public void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {

        SharedPreferences sharedPreferences = getActivity().getSharedPreferences(getActivity().getPackageName(), Context.MODE_PRIVATE);
        String message = sharedPreferences.getString(PREF_MESSAGE_KEY, null);
        String[] token=message.split(":");

        view.findViewById(R.id.btNewPassword).setOnClickListener(v->{
            String newPass=((EditText) view.findViewById(R.id.newPassword)).getText().toString();
            String confpass=((EditText) view.findViewById(R.id.confirmPassword)).getText().toString();
            if(newPass.equals(confpass) && !newPass.equals(token[1])) {
                String message2 = token[0] + ":" + newPass+":"+token[2];
                sharedPreferences
                        .edit()
                        .putString(PREF_MESSAGE_KEY, message2)
                        .apply();
                DBHelper dbHelper=new DBHelper(getActivity());
                dbHelper.updatePasswordForUser(token[2],newPass);
                FragmentTransaction transaction = getActivity().getSupportFragmentManager().beginTransaction();
                transaction.replace(R.id.addFragmentFcv, new FragmentProfile());
                transaction.commit();
                Toast toast = Toast.makeText(getActivity().getApplicationContext(), "PASSWORD HAS CHANGED", Toast.LENGTH_SHORT);
                toast.show();
                System.out.println("Nova lozinka je "+sharedPreferences.getString(PREF_MESSAGE_KEY, null).toString());
            }
            else{
                Toast toast = Toast.makeText(getActivity().getApplicationContext(), "CHANGE PASSWORD ERROR", Toast.LENGTH_SHORT);
                toast.show();
            }
        });


    }
}
