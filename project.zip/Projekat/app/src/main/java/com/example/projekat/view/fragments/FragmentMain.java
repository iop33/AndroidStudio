package com.example.projekat.view.fragments;

import android.os.Bundle;
import android.view.View;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentTransaction;
import androidx.lifecycle.ViewModelProvider;
import androidx.viewpager.widget.ViewPager;

import com.example.projekat.R;
import com.example.projekat.viewmodels.FlagViewModel;
import com.google.android.material.bottomnavigation.BottomNavigationView;

public class FragmentMain extends Fragment {

    private FlagViewModel flag;
    public FragmentMain() {
        super(R.layout.fragment_main);
    }
    @Override
    public void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        flag = new ViewModelProvider(requireActivity()).get(FlagViewModel.class);
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        ((BottomNavigationView)view.findViewById(R.id.bottomNavigation)).setSelectedItemId(R.id.calendar);
        FragmentTransaction transaction = this.getActivity().getSupportFragmentManager().beginTransaction();
        transaction.replace(R.id.fragmentContainerView, new FragmentCalendar());
        transaction.commit();

        ((BottomNavigationView)view.findViewById(R.id.bottomNavigation)).setOnItemSelectedListener(item ->{

                switch (item.getItemId()) {
                    // setCurrentItem metoda viewPager samo obavesti koji je Item trenutno aktivan i onda metoda getItem u adapteru setuje odredjeni fragment za tu poziciju
//                case R.id.calendar: {
//                    FragmentTransaction transaction = this.getActivity().getSupportFragmentManager().beginTransaction();
//                    transaction.replace(R.id.fragmentContainerView, new FragmentCalendar());
//                    transaction.commit();
//                    break;
//                }
                    case R.id.planner: {
                        FragmentTransaction transaction1 = this.getActivity().getSupportFragmentManager().beginTransaction();
                        transaction1.replace(R.id.fragmentContainerView, new FragmentPlanner());
                        transaction1.commit();
                        break;
                    }
                    case R.id.profile: {
                        FragmentTransaction transaction2 = this.getActivity().getSupportFragmentManager().beginTransaction();
                        transaction2.replace(R.id.fragmentContainerView, new FragmentProfile());
                        transaction2.commit();
                        break;
                    }
                    default: {
                        FragmentTransaction transaction3 = this.getActivity().getSupportFragmentManager().beginTransaction();
                        transaction3.replace(R.id.fragmentContainerView, new FragmentCalendar());
                        transaction3.commit();
                        break;
                    }
                }
                return true;
        });
    }
}
