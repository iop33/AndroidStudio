package com.example.projekat.view.recycler.differ;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.DiffUtil;

import com.example.projekat.model.DayEvent;

public class DayEventDifferItemCallback extends DiffUtil.ItemCallback<DayEvent>{
    @Override
    public boolean areItemsTheSame(@NonNull DayEvent oldItem, @NonNull DayEvent newItem) {
        return oldItem.getIme().equals(newItem.getIme());
    }

    @Override
    public boolean areContentsTheSame(@NonNull DayEvent oldItem, @NonNull DayEvent newItem) {
        return oldItem.getEventPriority().equals(newItem.getEventPriority())
                && oldItem.getOpis().equals(newItem.getOpis());
    }
}
