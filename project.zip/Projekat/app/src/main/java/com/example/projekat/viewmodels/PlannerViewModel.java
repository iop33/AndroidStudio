package com.example.projekat.viewmodels;

import androidx.lifecycle.LiveData;
import androidx.lifecycle.MutableLiveData;
import androidx.lifecycle.ViewModel;

import com.example.projekat.model.DayEvent;

import java.util.List;

public class PlannerViewModel extends ViewModel {
    private final MutableLiveData<List<DayEvent>> events = new MutableLiveData<>();

    public LiveData<List<DayEvent>> getEvents() {
        return events;
    }

    public void setDayEvents(List<DayEvent> dayEventList) {
        this.events.setValue(dayEventList);
    }
}
