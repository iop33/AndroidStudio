package com.example.projekat.view.fragments;

import android.content.Context;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentTransaction;

import com.example.projekat.R;
import com.google.android.material.bottomnavigation.BottomNavigationView;

public class FragmentProfile extends Fragment {

    public static final String PREF_MESSAGE_KEY = "prefMessageKey";
    public FragmentProfile() {super(R.layout.fragment_profile);}
    @Override
    public void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
    }
    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {

        SharedPreferences sharedPreferences = getActivity().getSharedPreferences(getActivity().getPackageName(), Context.MODE_PRIVATE);
        String message = sharedPreferences.getString(PREF_MESSAGE_KEY, null);
        if(message!=null){
            String[] token=message.split(":");
            String mejl=token[0];
            ((TextView) view.findViewById(R.id.mejl)).setText(mejl);
        }
        view.findViewById(R.id.logout).setOnClickListener(v->{
            sharedPreferences.edit().remove(PREF_MESSAGE_KEY).commit();
            FragmentTransaction transaction = getActivity().getSupportFragmentManager().beginTransaction();
            transaction.replace(R.id.addFragmentFcv, new FragmentLog());
            transaction.commit();
        });
        view.findViewById(R.id.changepassword).setOnClickListener(v->{
            FragmentTransaction transaction = getActivity().getSupportFragmentManager().beginTransaction();
            transaction.add(R.id.addFragmentFcv, new FragmentChangePassword()).addToBackStack(null);
            transaction.commit();
        });


    }


}
