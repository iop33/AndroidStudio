package com.example.projekat.view.fragments;

import android.os.Bundle;
import android.view.View;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentTransaction;
import androidx.lifecycle.ViewModelProvider;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.example.projekat.R;
import com.example.projekat.model.Day;
import com.example.projekat.view.recycler.adapter.DayAdapter;
import com.example.projekat.view.recycler.differ.DayDifferItemCallback;
import com.example.projekat.viewmodels.CalendarViewModel;
import com.example.projekat.viewmodels.DayPlannerViewModel;
import com.example.projekat.viewmodels.PlannerViewModel;

import java.time.LocalDate;

public class FragmentCalendar extends Fragment {
    private CalendarViewModel calendarVIewModel;
    private RecyclerView recyclerView;
    private DayAdapter dayAdapter;
    private DayPlannerViewModel dayPlannerViewModel;
    private boolean first = false;
    private boolean last = false;
    private TextView monthTv;
    private PlannerViewModel plannerViewModel;
    private Day day;
    public FragmentCalendar() {
        super(R.layout.fragment_calendar);
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        calendarVIewModel = new ViewModelProvider(requireActivity()).get(CalendarViewModel.class);
        plannerViewModel = new ViewModelProvider(requireActivity()).get(PlannerViewModel.class);
        dayPlannerViewModel=new ViewModelProvider(requireActivity()).get(DayPlannerViewModel.class);

        init(view);
        initObservers();
        initRecycler();
    }

    private void init(View view) {
        recyclerView = view.findViewById(R.id.recyclerView);
        monthTv = view.findViewById(R.id.monthTV);
    }

    private void initObservers() {
        calendarVIewModel.getDani().observe(this, dani -> {
            dayAdapter.submitList(dani);
        });

    }

    private void initRecycler() {
        for(int i = 0; i < calendarVIewModel.getDani().getValue().size(); i++) {
            if(calendarVIewModel.getDani().getValue().get(i).getDan().compareTo(LocalDate.now()) == 0) {
                day = calendarVIewModel.getDani().getValue().get(i);
            }
        }
        dayPlannerViewModel.setPlaner_dan(day);
        dayAdapter = new DayAdapter(new DayDifferItemCallback(), day -> {
            dayPlannerViewModel.setPlaner_dan(day);
            plannerViewModel.setDayEvents(day.getObaveze());
            FragmentTransaction transaction = this.getActivity().getSupportFragmentManager().beginTransaction();
            transaction.replace(R.id.fragmentContainerView, new FragmentPlanner()).addToBackStack(null);
            transaction.commit();
        });
        recyclerView.setLayoutManager(new GridLayoutManager(this.getActivity(),7));
        recyclerView.setAdapter(dayAdapter);
        GridLayoutManager layoutManager = (GridLayoutManager) recyclerView.getLayoutManager();
        LocalDate now = LocalDate.now();
        int dayInMonth = now.getDayOfMonth();
        // Namestam da recycler view pocne od trenutnog meseca
        // I da odmah u dayviewmodel setuje trenutan dan dan
        for(int i = 0; i < calendarVIewModel.getDani().getValue().size(); i++) {
            if(calendarVIewModel.getDani().getValue().get(i).getDan().equals(now)) {
                // Skrolujem na poziciju trenutna - dan u mesecu plus jedan da bi bio prvi
                layoutManager.scrollToPosition(i-dayInMonth+1);
            }
        }
        recyclerView.addOnScrollListener(new RecyclerView.OnScrollListener() {
            @Override
            public void onScrolled(@NonNull RecyclerView recyclerView, int dx, int dy) {
                super.onScrolled(recyclerView, dx, dy);
                int lastVisiblePosition = layoutManager.findLastCompletelyVisibleItemPosition();
                int firstVisiblePosition = layoutManager.findFirstCompletelyVisibleItemPosition();
                if(firstVisiblePosition != -1) {
                    for (int i = firstVisiblePosition; i <= lastVisiblePosition; i++) {
                        if (!first) {
                            if (calendarVIewModel.getDani().getValue().get(i).getDan().getDayOfMonth() == 1) {
                                last = false;
                                first = true;
                            }
                        } else {
                            if (calendarVIewModel.getDani().getValue().get(i).getDan().getDayOfMonth() == 1) {
                                last = true;
                                first = false;
                                // Uzimam dan iz liste koji je bio pre prvog da bih mogao da mu izvucem mesec
                                monthTv.setText(calendarVIewModel.getDani().getValue().get(i - 1).getDan().getMonth().toString() + " "
                                        + calendarVIewModel.getDani().getValue().get(i - 1).getDan().getYear() + ".");
                                break;
                            }
                        }
                    }
                }
            }
        });
    }
}
