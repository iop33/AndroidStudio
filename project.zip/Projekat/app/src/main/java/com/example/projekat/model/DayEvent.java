package com.example.projekat.model;

import java.time.LocalTime;

public class DayEvent {
    private String ime;
    private String opis;
    private LocalTime start;
    private LocalTime end;
    private Priority eventPriority;

    public DayEvent(String ime, String opis, LocalTime start, LocalTime end, Priority priority) {
        this.ime = ime;
        this.opis = opis;
        this.start = start;
        this.end = end;
        this.eventPriority = priority;
    }

    public String getIme() {
        return ime;
    }

    public void setIme(String ime) {
        this.ime = ime;
    }

    public String getOpis() {
        return opis;
    }

    public void setOpis(String opis) {
        this.opis = opis;
    }

    public LocalTime getStart() {
        return start;
    }

    public void setStart(LocalTime start) {
        this.start = start;
    }

    public LocalTime getEnd() {
        return end;
    }

    public void setEnd(LocalTime end) {
        this.end = end;
    }

    public Priority getEventPriority() {
        return eventPriority;
    }

    public void setEventPriority(Priority eventPriority) {
        this.eventPriority = eventPriority;
    }
}
