package com.example.projekat.view.recycler.adapter;

import android.content.Context;
import android.graphics.drawable.Drawable;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.DiffUtil;
import androidx.recyclerview.widget.ListAdapter;
import androidx.recyclerview.widget.RecyclerView;

import com.example.projekat.R;
import com.example.projekat.model.Day;
import com.example.projekat.model.Priority;

import java.util.function.Consumer;

public class DayAdapter extends ListAdapter<Day, DayAdapter.ViewHolder> {
    private final Consumer<Day> onDayClicked;

    public DayAdapter(@NonNull DiffUtil.ItemCallback<Day> diffCallback, Consumer<Day> onDayClicked) {
        super(diffCallback);
        this.onDayClicked = onDayClicked;
    }


    @NonNull
    @Override
    public DayAdapter.ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View itemView = LayoutInflater.from(parent.getContext()).inflate(R.layout.item_layout, parent, false);
        return new ViewHolder(itemView, parent.getContext(), position -> {
            Day day = getItem(position);
            onDayClicked.accept(day);
        });
    }

    @Override
    public void onBindViewHolder(@NonNull DayAdapter.ViewHolder holder, int position) {
        Day day = getItem(position);
        holder.bind(day);
    }

    public static class ViewHolder extends RecyclerView.ViewHolder {
        private final Context context;

        private ViewHolder(@NonNull View itemView, Context context, Consumer<Integer> onItemClicked) {
            super(itemView);
            this.context = context;
            itemView.setOnClickListener(v -> {
                if(getBindingAdapterPosition() != RecyclerView.NO_POSITION) {
                    onItemClicked.accept(getBindingAdapterPosition());
                }
            });
        }

        private void bind(Day day) {
            // TODO: namestiti da se poveze layout
            TextView textView = itemView.findViewById(R.id.dayItem);
            textView.setText(String.valueOf(day.getDan().getDayOfMonth()));
            Priority priority = day.getPriority();
            Drawable drawable = null;
            switch (priority) {
                case LOW:
                    drawable = context.getDrawable(R.drawable.low_day_box_plain);
                    break;
                case MID:
                    drawable = context.getDrawable(R.drawable.medium_day_box_plain);
                    break;
                case HIGH:
                    drawable = context.getDrawable(R.drawable.high_day_box_plain);
                    break;
                default:
                    drawable = context.getDrawable(R.drawable.day_box_plain);
                    break;
            }
            textView.setBackground(drawable);
        }
    }
}
